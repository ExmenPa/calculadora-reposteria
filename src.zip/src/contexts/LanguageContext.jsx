import React, { createContext, useState, useContext } from 'react';

const LanguageContext = createContext();

export const translations = {
  en: {
    appTitle: "Baking Calculator",
    viewRecipes: "View Recipes",
    recipesTitle: "Common Baking Recipes",
    recipesDesc: "Standard measurements for your favorite treats.",
    prep: "prep",
    bake: "bake",
    ingredient: "Ingredient",
    notNeeded: "Not needed for this conversion",
    amountToConvert: "Amount to Convert",
    enterAmount: "Enter amount",
    convertedResult: "Converted Result",
    didYouKnow: "Did you know?",
    tipDensityNeeded: "Since you're converting between weight and volume, selecting the correct ingredient above is crucial for accuracy.",
    tipDensityNotNeeded: "Since you're converting within the same category (e.g. weight to weight), the ingredient type doesn't affect the math.",
    selectUnit: "Select unit",
    selectIngredient: "Select ingredient",
    // Ingredients
    'water': 'Water (Standard)',
    'flour_ap': 'Flour (All-Purpose)',
    'flour_bread': 'Flour (Bread)',
    'flour_cake': 'Flour (Cake)',
    'sugar_granulated': 'Sugar (Granulated)',
    'sugar_powdered': 'Sugar (Powdered)',
    'sugar_brown': 'Sugar (Brown, Packed)',
    'butter': 'Butter',
    'milk': 'Milk',
    'oil': 'Vegetable Oil',
    'cocoa': 'Cocoa Powder',
    'oats': 'Rolled Oats',
    'honey': 'Honey',
    'salt': 'Table Salt',
    // Units
    'grams': 'Grams (g)',
    'kilograms': 'Kilograms (kg)',
    'ounces': 'Ounces (oz)',
    'pounds': 'Pounds (lb)',
    'cups': 'Cups',
    'tablespoons': 'Tablespoons (tbsp)',
    'liters': 'Liters (L)',
    // Recipes
    'chocolate_cake': 'Classic Chocolate Cake',
    'chocolate_cake_desc': 'Rich, moist, and deeply chocolatey.',
    'sourdough_bread': 'Rustic Sourdough Bread',
    'sourdough_bread_desc': 'Crusty outside, airy inside.',
    'choc_chip_cookies': 'Chewy Chocolate Chip Cookies',
    'choc_chip_cookies_desc': 'Soft centers with crispy edges.',
    'croissants': 'Butter Croissants',
    'croissants_desc': 'Flaky, buttery French pastry.',
  },
  es: {
    appTitle: "Calculadora de Repostería",
    viewRecipes: "Ver Recetas",
    recipesTitle: "Recetas Comunes",
    recipesDesc: "Medidas estándar para tus postres favoritos.",
    prep: "prep",
    bake: "horno",
    ingredient: "Ingrediente",
    notNeeded: "No es necesario para esta conversión",
    amountToConvert: "Cantidad a Convertir",
    enterAmount: "Ingresar cantidad",
    convertedResult: "Resultado Convertido",
    didYouKnow: "¿Sabías qué?",
    tipDensityNeeded: "Al convertir entre peso y volumen, seleccionar el ingrediente correcto arriba es crucial para la precisión.",
    tipDensityNotNeeded: "Al convertir dentro de la misma categoría (ej. peso a peso), el tipo de ingrediente no afecta el cálculo.",
    selectUnit: "Seleccionar unidad",
    selectIngredient: "Seleccionar ingrediente",
    // Ingredients
    'water': 'Agua (Estándar)',
    'flour_ap': 'Harina (Todo Uso)',
    'flour_bread': 'Harina (Pan)',
    'flour_cake': 'Harina (Pastel)',
    'sugar_granulated': 'Azúcar (Granulada)',
    'sugar_powdered': 'Azúcar (Glass)',
    'sugar_brown': 'Azúcar (Morena)',
    'butter': 'Mantequilla',
    'milk': 'Leche',
    'oil': 'Aceite Vegetal',
    'cocoa': 'Cacao en Polvo',
    'oats': 'Avena',
    'honey': 'Miel',
    'salt': 'Sal de Mesa',
    // Units
    'grams': 'Gramos (g)',
    'kilograms': 'Kilogramos (kg)',
    'ounces': 'Onzas (oz)',
    'pounds': 'Libras (lb)',
    'cups': 'Tazas',
    'tablespoons': 'Cucharadas (cda)',
    'liters': 'Litros (L)',
    // Recipes
    'chocolate_cake': 'Pastel de Chocolate Clásico',
    'chocolate_cake_desc': 'Rico, húmedo y muy chocolatoso.',
    'sourdough_bread': 'Pan de Masa Madre',
    'sourdough_bread_desc': 'Crujiente por fuera, aireado por dentro.',
    'choc_chip_cookies': 'Galletas con Chispas',
    'choc_chip_cookies_desc': 'Centro suave con bordes crujientes.',
    'croissants': 'Croissants de Mantequilla',
    'croissants_desc': 'Hojaldre francés mantecoso.',
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'es' : 'en');
  };

  const t = (key) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);