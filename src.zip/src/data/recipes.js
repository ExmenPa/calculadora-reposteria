export const recipes = [
  {
    id: 'chocolate_cake',
    title: 'Classic Chocolate Cake',
    description: 'Rich, moist, and deeply chocolatey.',
    prepTime: '20 mins',
    bakeTime: '35 mins',
    ingredients: [
      { name: 'All-Purpose Flour', amount: '1 ¾', unit: 'cups' },
      { name: 'Granulated Sugar', amount: '2', unit: 'cups' },
      { name: 'Cocoa Powder', amount: '¾', unit: 'cup' },
      { name: 'Baking Powder', amount: '1 ½', unit: 'tsp' },
      { name: 'Baking Soda', amount: '1 ½', unit: 'tsp' },
      { name: 'Salt', amount: '1', unit: 'tsp' },
      { name: 'Eggs', amount: '2', unit: 'large' },
      { name: 'Milk', amount: '1', unit: 'cup' },
      { name: 'Vegetable Oil', amount: '½', unit: 'cup' },
      { name: 'Vanilla Extract', amount: '2', unit: 'tsp' },
      { name: 'Boiling Water', amount: '1', unit: 'cup' },
    ]
  },
  {
    id: 'sourdough_bread',
    title: 'Rustic Sourdough Bread',
    description: 'Crusty outside, airy inside.',
    prepTime: '45 mins',
    bakeTime: '45 mins',
    ingredients: [
      { name: 'Bread Flour', amount: '500', unit: 'g' },
      { name: 'Water (Warm)', amount: '350', unit: 'g' },
      { name: 'Sourdough Starter', amount: '100', unit: 'g' },
      { name: 'Salt', amount: '10', unit: 'g' },
    ]
  },
  {
    id: 'choc_chip_cookies',
    title: 'Chewy Chocolate Chip Cookies',
    description: 'Soft centers with crispy edges.',
    prepTime: '15 mins',
    bakeTime: '10 mins',
    ingredients: [
      { name: 'Butter (Melted)', amount: '1', unit: 'cup' },
      { name: 'White Sugar', amount: '1', unit: 'cup' },
      { name: 'Brown Sugar', amount: '1', unit: 'cup' },
      { name: 'Eggs', amount: '2', unit: 'large' },
      { name: 'Vanilla Extract', amount: '2', unit: 'tsp' },
      { name: 'Baking Soda', amount: '1', unit: 'tsp' },
      { name: 'Hot Water', amount: '2', unit: 'tsp' },
      { name: 'Salt', amount: '½', unit: 'tsp' },
      { name: 'All-Purpose Flour', amount: '3', unit: 'cups' },
      { name: 'Chocolate Chips', amount: '2', unit: 'cups' },
    ]
  },
  {
    id: 'croissants',
    title: 'Butter Croissants',
    description: 'Flaky, buttery French pastry.',
    prepTime: '60 mins',
    bakeTime: '20 mins',
    ingredients: [
      { name: 'All-Purpose Flour', amount: '4', unit: 'cups' },
      { name: 'Sugar', amount: '1/3', unit: 'cup' },
      { name: 'Active Dry Yeast', amount: '1', unit: 'tbsp' },
      { name: 'Salt', amount: '2', unit: 'tsp' },
      { name: 'Milk (Warm)', amount: '1 ¼', unit: 'cups' },
      { name: 'Butter (Cold, for laminating)', amount: '1 ½', unit: 'cups' },
      { name: 'Egg (for wash)', amount: '1', unit: 'large' },
    ]
  }
];