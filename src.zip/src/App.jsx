import React from 'react';
import { Helmet } from 'react-helmet';
import UnitConverter from '@/components/UnitConverter';
import { LanguageProvider } from '@/contexts/LanguageContext';

function App() {
  return (
    <LanguageProvider>
      <Helmet>
        <title>Baking Unit Converter - Convert Ingredients Instantly</title>
        <meta name="description" content="Convert baking ingredients between grams, kilograms, ounces, pounds, cups, tablespoons, and liters instantly. Perfect for recipe conversions." />
      </Helmet>
      <div
        className='min-h-screen flex flex-col items-center justify-center p-4 overflow-hidden relative'
        style={{
          background: `radial-gradient(100% 100% at 50% 100%, var(--Gradients-Main-Color-4, #FF9875) 0%, var(--Gradients-Main-Color-3, #B452FF) 15%, var(--Gradients-Main-Color-2, #673DE6) 30%, var(--neutral--800, #1a1b1e) 80%)`
        }}
      >
        <UnitConverter />
      </div>
    </LanguageProvider>
  );
}

export default App;