import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ingredients } from '@/utils/conversionUtils';
import { useLanguage } from '@/contexts/LanguageContext';

const IngredientSelect = ({ value, onChange }) => {
  const { t } = useLanguage();

  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className='w-full bg-white/20 border-white/30 text-white focus:ring-2 focus:ring-orange-400 hover:bg-white/30 transition-all'>
        <SelectValue placeholder={t('selectIngredient')} />
      </SelectTrigger>
      <SelectContent className='bg-slate-800 border-white/20 max-h-[300px] overflow-y-auto'>
        {ingredients.map((item) => (
          <SelectItem
            key={item.id}
            value={item.id}
            className='text-white hover:bg-white/10 focus:bg-white/20 cursor-pointer'
          >
            {t(item.id)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default IngredientSelect;