import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRightLeft, ChefHat, Info, Languages } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import UnitSelect from '@/components/UnitSelect';
import IngredientSelect from '@/components/IngredientSelect';
import RecipeBook from '@/components/RecipeBook';
import { convertUnits, getUnitCategory } from '@/utils/conversionUtils';
import { useLanguage } from '@/contexts/LanguageContext';

const UnitConverter = () => {
  const { t, language, toggleLanguage } = useLanguage();
  const [inputValue, setInputValue] = useState('1');
  const [sourceUnit, setSourceUnit] = useState('cups');
  const [targetUnit, setTargetUnit] = useState('grams');
  const [ingredient, setIngredient] = useState('flour_ap');
  const [result, setResult] = useState('');
  const [needsDensity, setNeedsDensity] = useState(true);

  // Check if we need density calculation (Weight <-> Volume)
  useEffect(() => {
    const sourceCat = getUnitCategory(sourceUnit);
    const targetCat = getUnitCategory(targetUnit);
    setNeedsDensity(sourceCat !== targetCat);
  }, [sourceUnit, targetUnit]);

  useEffect(() => {
    if (inputValue && !isNaN(inputValue) && parseFloat(inputValue) >= 0) {
      const converted = convertUnits(
        parseFloat(inputValue), 
        sourceUnit, 
        targetUnit, 
        ingredient
      );
      setResult(converted.toFixed(2));
    } else {
      setResult('');
    }
  }, [inputValue, sourceUnit, targetUnit, ingredient]);

  const handleSwapUnits = () => {
    setSourceUnit(targetUnit);
    setTargetUnit(sourceUnit);
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    if (value === '' || (!isNaN(value) && parseFloat(value) >= 0)) {
      setInputValue(value);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className='w-full max-w-2xl'
    >
      <div className='bg-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 shadow-2xl border border-white/20'>
        {/* Header */}
        <div className='flex flex-col gap-4 mb-8'>
          <div className="flex items-center justify-between w-full">
            <div className='flex items-center gap-3'>
              <motion.div
                initial={{ rotate: -10 }}
                animate={{ rotate: 0 }}
                transition={{ duration: 0.5 }}
              >
                <ChefHat className='w-10 h-10 text-orange-300' />
              </motion.div>
              <h1 className='text-2xl md:text-3xl font-bold text-white'>
                {t('appTitle')}
              </h1>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="text-white hover:bg-white/20 rounded-full flex items-center gap-2"
            >
              <Languages className="w-4 h-4" />
              <span className="font-medium uppercase">{language}</span>
            </Button>
          </div>

          <div className="flex justify-end w-full">
             <RecipeBook />
          </div>
        </div>

        <div className='space-y-6'>
          {/* Ingredient Selection */}
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ 
              opacity: needsDensity ? 1 : 0.5, 
              height: 'auto',
              filter: needsDensity ? 'none' : 'grayscale(100%)'
            }}
            className='space-y-2'
          >
            <div className="flex items-center justify-between">
              <Label className='text-white/90 text-lg font-medium'>
                {t('ingredient')}
              </Label>
              {!needsDensity && (
                <span className="text-xs text-white/50 italic">
                  {t('notNeeded')}
                </span>
              )}
            </div>
            <IngredientSelect value={ingredient} onChange={setIngredient} />
          </motion.div>

          {/* Input Section */}
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className='space-y-3'
          >
            <Label htmlFor='input-value' className='text-white/90 text-lg font-medium'>
              {t('amountToConvert')}
            </Label>
            <div className='flex gap-3 flex-col sm:flex-row'>
              <input
                id='input-value'
                type='number'
                min='0'
                step='any'
                value={inputValue}
                onChange={handleInputChange}
                className='flex-1 px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all text-lg min-w-0'
                placeholder={t('enterAmount')}
              />
              <div className="w-full sm:w-[180px]">
                <UnitSelect value={sourceUnit} onChange={setSourceUnit} />
              </div>
            </div>
          </motion.div>

          {/* Swap Button */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
            className='flex justify-center -my-2 relative z-10'
          >
            <Button
              onClick={handleSwapUnits}
              variant='ghost'
              size='icon'
              className='rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-600 transition-all duration-300 hover:scale-110 w-10 h-10 shadow-lg'
            >
              <ArrowRightLeft className='w-4 h-4 text-white' />
            </Button>
          </motion.div>

          {/* Output Section */}
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className='space-y-3'
          >
            <Label htmlFor='output-value' className='text-white/90 text-lg font-medium'>
              {t('convertedResult')}
            </Label>
            <div className='flex gap-3 flex-col sm:flex-row'>
              <div className='flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-orange-500/30 to-pink-500/30 border border-white/30 text-white text-lg font-semibold flex items-center min-h-[54px]'>
                {result || '0.00'}
              </div>
              <div className="w-full sm:w-[180px]">
                <UnitSelect value={targetUnit} onChange={setTargetUnit} />
              </div>
            </div>
          </motion.div>

          {/* Info Card */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className='mt-8 p-4 rounded-xl bg-white/5 border border-white/10 flex gap-3'
          >
            <Info className="w-5 h-5 text-orange-300 flex-shrink-0 mt-0.5" />
            <p className='text-white/70 text-sm'>
              <span className='font-medium text-orange-200'>{t('didYouKnow')}</span>{' '}
              {needsDensity 
                ? t('tipDensityNeeded') 
                : t('tipDensityNotNeeded')}
            </p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default UnitConverter;