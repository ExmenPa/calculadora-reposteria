import React from 'react';
import { BookOpen, Clock, ChefHat } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { recipes } from '@/data/recipes';
import { useLanguage } from '@/contexts/LanguageContext';

const RecipeBook = () => {
  const { t } = useLanguage();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white border-dashed w-full sm:w-auto"
        >
          <BookOpen className="w-4 h-4 mr-2" />
          {t('viewRecipes')}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-slate-900 border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <ChefHat className="text-orange-400" />
            {t('recipesTitle')}
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            {t('recipesDesc')}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-6 mt-4">
          {recipes.map((recipe) => (
            <div 
              key={recipe.id} 
              className="rounded-xl border border-slate-700 bg-slate-800/50 p-4 transition-all hover:bg-slate-800"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-orange-300">
                    {t(recipe.id)}
                  </h3>
                  <p className="text-sm text-slate-400">
                    {t(`${recipe.id}_desc`)}
                  </p>
                </div>
                <div className="flex items-center text-xs text-slate-400 bg-slate-900 px-2 py-1 rounded whitespace-nowrap">
                  <Clock className="w-3 h-3 mr-1" />
                  {recipe.prepTime.replace('mins', 'min')} {t('prep')} / {recipe.bakeTime.replace('mins', 'min')} {t('bake')}
                </div>
              </div>
              
              <div className="grid sm:grid-cols-2 gap-2 text-sm">
                {recipe.ingredients.map((ing, idx) => (
                  <div key={idx} className="flex justify-between border-b border-slate-700/50 pb-1 last:border-0">
                    <span className="text-slate-300">{ing.name}</span>
                    <span className="font-mono text-orange-200/80">
                      {ing.amount} {ing.unit}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RecipeBook;