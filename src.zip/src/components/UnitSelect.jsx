import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLanguage } from '@/contexts/LanguageContext';

const units = [
  { value: 'grams' },
  { value: 'kilograms' },
  { value: 'ounces' },
  { value: 'pounds' },
  { value: 'cups' },
  { value: 'tablespoons' },
  { value: 'liters' },
];

const UnitSelect = ({ value, onChange }) => {
  const { t } = useLanguage();
  
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className='w-full bg-white/20 border-white/30 text-white focus:ring-2 focus:ring-orange-400 hover:bg-white/30 transition-all'>
        <SelectValue placeholder={t('selectUnit')} />
      </SelectTrigger>
      <SelectContent className='bg-slate-800 border-white/20'>
        {units.map((unit) => (
          <SelectItem
            key={unit.value}
            value={unit.value}
            className='text-white hover:bg-white/10 focus:bg-white/20 cursor-pointer'
          >
            {t(unit.value)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default UnitSelect;