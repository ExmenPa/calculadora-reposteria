// Conversion factors
// Weight units (base: grams)
// Volume units (base: milliliters)

const conversionTable = {
  // Weight
  grams: 1,
  kilograms: 1000,
  ounces: 28.3495,
  pounds: 453.592,
  
  // Volume (1 cup = 236.588 ml)
  cups: 236.588,
  tablespoons: 14.787,
  liters: 1000,
};

// Density in g/ml
export const ingredients = [
  { id: 'water', label: 'Water (Standard)', density: 1.0 },
  { id: 'flour_ap', label: 'Flour (All-Purpose)', density: 0.53 },
  { id: 'flour_bread', label: 'Flour (Bread)', density: 0.54 },
  { id: 'flour_cake', label: 'Flour (Cake)', density: 0.48 },
  { id: 'sugar_granulated', label: 'Sugar (Granulated)', density: 0.85 },
  { id: 'sugar_powdered', label: 'Sugar (Powdered)', density: 0.56 },
  { id: 'sugar_brown', label: 'Sugar (Brown, Packed)', density: 0.93 },
  { id: 'butter', label: 'Butter', density: 0.96 },
  { id: 'milk', label: 'Milk', density: 1.03 },
  { id: 'oil', label: 'Vegetable Oil', density: 0.92 },
  { id: 'cocoa', label: 'Cocoa Powder', density: 0.45 },
  { id: 'oats', label: 'Rolled Oats', density: 0.38 },
  { id: 'honey', label: 'Honey', density: 1.42 },
  { id: 'salt', label: 'Table Salt', density: 1.20 },
];

export const getUnitCategory = (unit) => {
  const weightUnits = ['grams', 'kilograms', 'ounces', 'pounds'];
  const volumeUnits = ['cups', 'tablespoons', 'liters'];
  
  if (weightUnits.includes(unit)) return 'weight';
  if (volumeUnits.includes(unit)) return 'volume';
  return 'unknown';
};

export const convertUnits = (value, fromUnit, toUnit, ingredientId = 'water') => {
  if (!value || isNaN(value)) return 0;
  
  const fromCategory = getUnitCategory(fromUnit);
  const toCategory = getUnitCategory(toUnit);
  const ingredient = ingredients.find(i => i.id === ingredientId) || ingredients[0];
  const density = ingredient.density;

  // 1. Convert 'from' unit to base unit (grams or ml)
  let baseValue = value * conversionTable[fromUnit];

  // 2. If categories differ, convert using density
  // Weight (g) to Volume (ml) -> ml = g / density
  // Volume (ml) to Weight (g) -> g = ml * density
  
  if (fromCategory === 'weight' && toCategory === 'volume') {
    // baseValue is currently grams. Convert to ml.
    baseValue = baseValue / density; 
  } else if (fromCategory === 'volume' && toCategory === 'weight') {
    // baseValue is currently ml. Convert to grams.
    baseValue = baseValue * density;
  }

  // 3. Convert from base unit to 'to' unit
  // If we switched categories, baseValue is now in the 'to' category's base unit (ml or g)
  // so we just divide by the 'to' unit factor.
  const result = baseValue / conversionTable[toUnit];
  
  return result;
};